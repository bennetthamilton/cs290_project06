<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$database_hostname = "localhost";
$database_port = 8889;
$database_username = "motorcycle_mania";
$database_password = "password";
$database_db_name = "motorcycle_mania";

// Note: These are intentionally insecure.
//       You should never store this file within the
//       webroot directory, in version control, or in
//       a file at all. The modern way? Environment
//       variables with 'dotenv', or however the framework
//       (eg Laravel) wants you to do it.
?>
