</main>
  <footer>
    <p>&copy; 2020 YOUR NAME</p>
  </footer>
</body>
</html>
