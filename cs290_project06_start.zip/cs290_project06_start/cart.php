<?php include 'header.php'; ?>
<h2>Your Shopping Cart</h2>
<?php include 'footer.php'; ?>
